# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=[= |MoonBase|™ Fury-Bengal SD662 CAF CustoKernal =]
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=0
device.name1=citrus
device.name2=lime
device.name3=lemon
device.name4=pomelo
device.name5=juice
supported.versions=11.0 - 12.0
supported.patchlevels=
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
set_perm_recursive 0 0 755 644 $ramdisk/*;
set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;

# moontunables chmod a+x
set_perm_recursive 0 0 750 750 $modules/data/adb/service.d/*;

# Info
ui_print "Device: Poco M3 (Citrus) / Redmi 9T (Lime)"
ui_print "Kver: 4.19.205-SD662-Fury-perf _rV18"
ui_print "Soc: Bengal , Caf Tag: 'LA.UM.9.15.r1-03400-KAMORTA.0'"
ui_print "Build Using: Gnu/Gcc-11.2.1 Stable"
ui_print "Date: Sunday, Friday, August 27 2021"
ui_print "Signed-off-by: Carlos Jimenez (JavaShin-X) <javashin1986@gmail.com>"

dump_boot;
write_boot;
